package com.example.yahtzee

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.view.isVisible
import java.util.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var lastPressed = 0
        var totalRolls = 0
        var amountDisabled = 0

        //hold variables
        var h1 = false
        var h2 = false
        var h3 = false
        var h4 = false
        var h5 = false

        //lock images
        val lockImage1 = findViewById<ImageView>(R.id.lockImage1)
        val lockImage2 = findViewById<ImageView>(R.id.lockImage2)
        val lockImage3 = findViewById<ImageView>(R.id.lockImage3)
        val lockImage4 = findViewById<ImageView>(R.id.lockImage4)
        val lockImage5 = findViewById<ImageView>(R.id.lockImage5)
        lockImage1.visibility = View.INVISIBLE
        lockImage2.isVisible = false
        lockImage3.isVisible = false
        lockImage4.isVisible = false
        lockImage5.isVisible = false

        //dice variables
        val die1 = findViewById<TextView>(R.id.die1)
        val die2 = findViewById<TextView>(R.id.die2)
        val die3 = findViewById<TextView>(R.id.die3)
        val die4 = findViewById<TextView>(R.id.die4)
        val die5 = findViewById<TextView>(R.id.die5)

        //upper level
        val aceButton = findViewById<Button>(R.id.aceButton)
        val twoButton = findViewById<Button>(R.id.twoButton)
        val threeButton = findViewById<Button>(R.id.threeButton)
        val fourButton = findViewById<Button>(R.id.fourButton)
        val fiveButton = findViewById<Button>(R.id.fiveButton)
        val sixButton = findViewById<Button>(R.id.sixButton)

        //lower level
        val threeKindButton = findViewById<Button>(R.id.threeKindButton)
        val fourKindButton = findViewById<Button>(R.id.fourKindButton)
        val fullHouseButton = findViewById<Button>(R.id.fullHouseButton)
        val smallStraightButton = findViewById<Button>(R.id.smallStraightButton)
        val largeStraightButton = findViewById<Button>(R.id.largeStraightButton)
        val chanceButton = findViewById<Button>(R.id.chanceButton)
        val yahtzeeButton = findViewById<Button>(R.id.yahtzeeButton)

        //hold buttons
        val hold1 = findViewById<Button>(R.id.hold1)
        val hold2 = findViewById<Button>(R.id.hold2)
        val hold3 = findViewById<Button>(R.id.hold3)
        val hold4 = findViewById<Button>(R.id.hold4)
        val hold5 = findViewById<Button>(R.id.hold5)
        hold1.isEnabled = false
        hold2.isEnabled = false
        hold3.isEnabled = false
        hold4.isEnabled = false
        hold5.isEnabled = false

        val enterButton = findViewById<Button>(R.id.enterButton)
        enterButton.isEnabled = false
        val rollButton = findViewById<Button>(R.id.rollButton)
        val newGameButton = findViewById<Button>(R.id.newGameButton)

        val singleScoreView = findViewById<TextView>(R.id.singleScoreView)
        val totalScoreView = findViewById<TextView>(R.id.totalScoreTextViewy)
        val rollView = findViewById<TextView>(R.id.rollView)
        val messageTextView = findViewById<TextView>(R.id.messageTextView)

        //calculating score values for upper section
        fun calculateNumber(num: Int) {
            lastPressed = num
            val strNum = num.toString()
            var total = 0
            if (die1.text == strNum)
                total += num
            if (die2.text == strNum)
                total += num
            if (die3.text == strNum)
                total += num
            if (die4.text == strNum)
                total += num
            if (die5.text == strNum)
                total += num
            singleScoreView.text = total.toString()
        }

        //gets the total value of all dice
        fun totalDice() {
            var total = 0
            total += die1.text.toString().toInt()
            total += die2.text.toString().toInt()
            total += die3.text.toString().toInt()
            total += die4.text.toString().toInt()
            total += die5.text.toString().toInt()
            singleScoreView.text = total.toString()
        }

        //disables all holds currently active
        fun resetHolds() {
            h1 = false
            h2 = false
            h3 = false
            h4 = false
            h5 = false

            lockImage1.isVisible = false
            lockImage2.isVisible = false
            lockImage3.isVisible = false
            lockImage4.isVisible = false
            lockImage5.isVisible = false
        }

        //ran when the enter button is pressed
        enterButton.setOnClickListener {
            if(lastPressed != 0) {
                hold1.isEnabled = false
                hold2.isEnabled = false
                hold3.isEnabled = false
                hold4.isEnabled = false
                hold5.isEnabled = false
                enterButton.isEnabled = false
                rollButton.isEnabled = true
                resetHolds()
                if (lastPressed == 1) {
                    aceButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 2) {
                    twoButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 3) {
                    threeButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 4) {
                    fourButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 5) {
                    fiveButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 6) {
                    sixButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 7) {
                    threeKindButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 8) {
                    fourKindButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 9) {
                    fullHouseButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 10) {
                    smallStraightButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 11) {
                    largeStraightButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 12) {
                    chanceButton.isEnabled = false
                    amountDisabled++
                } else if (lastPressed == 13) {
                    yahtzeeButton.isEnabled = false
                    amountDisabled++
                }
                lastPressed = 0
                var totalScore = totalScoreView.text.toString().toInt()
                totalScore += singleScoreView.text.toString().toInt()
                totalScoreView.text = totalScore.toString()
                singleScoreView.text = "0"
                totalRolls = 0
                rollView.text = "0"
                if(amountDisabled >= 13) {
                    messageTextView.text = "Game Finished"
                    rollButton.isEnabled = false
            }
            }
        }

        //ran when new game button is pressed, used to reset variables so the game and start again
        newGameButton.setOnClickListener {
            lastPressed = 0
            totalRolls = 0

            amountDisabled = 0

            resetHolds()

            hold1.isEnabled = false
            hold2.isEnabled = false
            hold3.isEnabled = false
            hold4.isEnabled = false
            hold5.isEnabled = false

            enterButton.isEnabled = false
            rollButton.isEnabled = true

            aceButton.isEnabled = true
            twoButton.isEnabled = true
            threeButton.isEnabled = true
            fourButton.isEnabled = true
            fiveButton.isEnabled = true
            sixButton.isEnabled = true
            threeKindButton.isEnabled = true
            fourKindButton.isEnabled = true
            fullHouseButton.isEnabled = true
            smallStraightButton.isEnabled = true
            largeStraightButton.isEnabled = true
            chanceButton.isEnabled = true
            yahtzeeButton.isEnabled = true

            resetHolds()

            singleScoreView.text = "0"
            totalScoreView.text = "0"
            rollView.text = "0"

            messageTextView.text = ""
        }

        //generates a values from 1-6 for each of the five dice.
        rollButton.setOnClickListener {
            if(totalRolls < 3) {
                hold1.isEnabled = true
                hold2.isEnabled = true
                hold3.isEnabled = true
                hold4.isEnabled = true
                hold5.isEnabled = true
                enterButton.isEnabled = true
                singleScoreView.text = "0"
                lastPressed = 0
                var rand = Random().nextInt(6) + 1
                if (!h1)
                    die1.text = rand.toString()

                rand = Random().nextInt(6) + 1
                if (!h2)
                    die2.text = rand.toString()

                rand = Random().nextInt(6) + 1
                if (!h3)
                    die3.text = rand.toString()

                rand = Random().nextInt(6) + 1
                if (!h4)
                    die4.text = rand.toString()

                rand = Random().nextInt(6) + 1
                if (!h5)
                    die5.text = rand.toString()
                totalRolls++
                rollView.text = totalRolls.toString()
                if (totalRolls >= 3)
                    rollButton.isEnabled = false

            }

        }

        hold1.setOnClickListener {
            h1 = !h1
            if(h1)
                lockImage1.isVisible = true
            else
                lockImage1.isVisible = false
        }
        hold2.setOnClickListener {
            h2 = !h2
            if(h2)
                lockImage2.isVisible = true
            else
                lockImage2.isVisible = false
        }
        hold3.setOnClickListener {
            h3 = !h3
            if(h3)
                lockImage3.isVisible = true
            else
                lockImage3.isVisible = false
        }
        hold4.setOnClickListener {
            h4 = !h4
            if(h4)
                lockImage4.isVisible = true
            else
                lockImage4.isVisible = false
        }
        hold5.setOnClickListener {
            h5 = !h5
            if(h5)
                lockImage5.isVisible = true
            else
                lockImage5.isVisible = false
        }

        aceButton.setOnClickListener {
            calculateNumber(1)
        }
        twoButton.setOnClickListener {
            calculateNumber(2)
        }
        threeButton.setOnClickListener {
            calculateNumber(3)
        }
        fourButton.setOnClickListener {
            calculateNumber(4)
        }
        fiveButton.setOnClickListener {
            calculateNumber(5)
        }
        sixButton.setOnClickListener {
            calculateNumber(6)
        }

        threeKindButton.setOnClickListener {
            lastPressed = 7
            var x = 0
            for(i in 1..6){
                x = 0
                if(die1.text == i.toString())
                    x += 1
                if(die2.text == i.toString())
                    x += 1
                if(die3.text == i.toString())
                    x += 1
                if(die4.text == i.toString())
                    x += 1
                if(die5.text == i.toString())
                    x += 1
                if(x >= 3) {
                    totalDice()
                    break
                }
                if(i == 6){
                    singleScoreView.text = "0"
                }
            }
        }

        fourKindButton.setOnClickListener {
            lastPressed = 8
            var x = 0
            for(i in 1..6){
                x = 0
                if(die1.text == i.toString())
                    x += 1
                if(die2.text == i.toString())
                    x += 1
                if(die3.text == i.toString())
                    x += 1
                if(die4.text == i.toString())
                    x += 1
                if(die5.text == i.toString())
                    x += 1
                if(x >= 4) {
                    totalDice()
                    break
                }
                if(i == 6){
                    singleScoreView.text = "0"
                }
            }
        }

        fullHouseButton.setOnClickListener {
            lastPressed = 9
            var x = die1.text
            var y = die1.text
            if(die2.text != die1.text){
                y = die2.text
            } else if(die3.text != die1.text){
                y = die3.text
            } else if(die4.text != die1.text){
                y = die4.text
            }

            if(x != y) {
                var f1 = 0
                var f2 = 0

                if (die1.text == x)
                    f1 += 1
                else if (die1.text == y)
                    f2 += 1

                if (die2.text == x)
                    f1 += 1
                else if (die2.text == y)
                    f2 += 1

                if (die3.text == x)
                    f1 += 1
                else if (die3.text == y)
                    f2 += 1

                if (die4.text == x)
                    f1 += 1
                else if (die4.text == y)
                    f2 += 1

                if (die5.text == x)
                    f1 += 1
                else if (die5.text == y)
                    f2 += 1

                if ((f1 == 3 && f2 == 2) || (f1 == 2 && f2 == 3))
                    singleScoreView.text = "25"
                else
                    singleScoreView.text = "0"
            }else {
                singleScoreView.text = "0"
            }

        }

        smallStraightButton.setOnClickListener {
            lastPressed = 10
            val sortedDice = mutableListOf(die1.text.toString().toInt(), die2.text.toString().toInt(), die3.text.toString().toInt(), die4.text.toString().toInt(), die5.text.toString().toInt())
            sortedDice.sort()

            var length = 1

            for(i in 0..3){
                if((sortedDice[i] + 1) == sortedDice[i+1]){
                    length++
                } else if(sortedDice[i] != sortedDice[i+1]){
                    length = 1
                }
                if(length == 4){
                    singleScoreView.text = "30"
                    break
                }
                if(i == 3){
                    singleScoreView.text = "0"
                }
            }
        }

        largeStraightButton.setOnClickListener {
            lastPressed = 11
            val sortedDice = mutableListOf(die1.text.toString().toInt(), die2.text.toString().toInt(), die3.text.toString().toInt(), die4.text.toString().toInt(), die5.text.toString().toInt())
            sortedDice.sort()

            var length = 1

            for (i in 0..3) {
                if (sortedDice[i] + 1 == sortedDice[i + 1]) {
                    length++
                } else if (sortedDice[i] != sortedDice[i + 1]) {
                    length = 1
                }
                if (length == 5) {
                    singleScoreView.text = "40"
                    break
                }
                if(i == 3){
                    singleScoreView.text = "0"
                }
            }

        }
        chanceButton.setOnClickListener {
            lastPressed = 12
            totalDice()
        }

        yahtzeeButton.setOnClickListener {
            lastPressed = 13
            val dice = mutableListOf(die1.text.toString().toInt(), die2.text.toString().toInt(), die3.text.toString().toInt(), die4.text.toString().toInt(), die5.text.toString().toInt())
            val die1 = dice[0]
            var fail = false

            for(i in 1..3){
                if(dice[i] != die1)
                    fail = true
            }

            if(fail) {
                singleScoreView.text = "0"
            } else {
                singleScoreView.text = "50"
            }
        }


    }


}
